import 'package:flutter/material.dart';
import '../../api/api_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _formKey = GlobalKey<FormState>();

  final nameCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final nationalIdCtrl = TextEditingController();
  final usernameCtrl = TextEditingController();

  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool loading = true;
  bool saving = false;
  bool isEditing = false;

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  // ===============================
  // تحميل بيانات المستخدم
  // ===============================
  Future<void> loadProfile() async {
    try {
      final data = await ApiService.fetchProfile();

      nameCtrl.text = data["full_name"] ?? "";
      emailCtrl.text = data["email"] ?? "";
      phoneCtrl.text = data["phone"] ?? "";
      nationalIdCtrl.text = data["national_id"] ?? "";
      usernameCtrl.text = data["username"] ?? "";
    } catch (e) {
      showMsg("تعذر تحميل بيانات المستخدم");
    }

    setState(() => loading = false);
  }

  // ===============================
  // تحديث البيانات
  // ===============================
  Future<void> updateProfile() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => saving = true);

    try {
      await ApiService.updateProfile(
        fullName: nameCtrl.text,
        email: emailCtrl.text,
        phone: phoneCtrl.text,
      );

      showMsg("تم تحديث البيانات");
      setState(() => isEditing = false);
    } catch (e) {
      showMsg("فشل تحديث البيانات");
    }

    setState(() => saving = false);
  }

  // ===============================
  // تغيير كلمة المرور
  // ===============================
  Future<void> changePassword() async {
    if (newPassCtrl.text != confirmPassCtrl.text) {
      showMsg("كلمة المرور غير متطابقة");
      return;
    }

    setState(() => saving = true);

    try {
      await ApiService.changePassword(
        oldPassword: oldPassCtrl.text,
        newPassword: newPassCtrl.text,
        confirmPassword: confirmPassCtrl.text,
      );

      showMsg("تم تغيير كلمة المرور");

      oldPassCtrl.clear();
      newPassCtrl.clear();
      confirmPassCtrl.clear();
    } catch (e) {
      showMsg("تعذر تغيير كلمة المرور");
    }

    setState(() => saving = false);
  }

  void showMsg(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    nameCtrl.dispose();
    emailCtrl.dispose();
    phoneCtrl.dispose();
    nationalIdCtrl.dispose();
    usernameCtrl.dispose();
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text("الإعدادات")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("بيانات المستخدم",
                  style: TextStyle(fontSize: 18)),

              const SizedBox(height: 15),

              TextFormField(
                controller: usernameCtrl,
                readOnly: true,
                decoration: const InputDecoration(
                  labelText: "اسم المستخدم",
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 12),

              TextFormField(
                controller: nationalIdCtrl,
                readOnly: true,
                decoration: const InputDecoration(
                  labelText: "رقم الهوية",
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 12),

              TextFormField(
                controller: nameCtrl,
                readOnly: !isEditing,
                decoration: const InputDecoration(
                  labelText: "الاسم الكامل",
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 12),

              TextFormField(
                controller: emailCtrl,
                readOnly: !isEditing,
                decoration: const InputDecoration(
                  labelText: "البريد الإلكتروني",
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 12),

              TextFormField(
                controller: phoneCtrl,
                readOnly: !isEditing,
                decoration: const InputDecoration(
                  labelText: "رقم الجوال",
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 20),

              if (!isEditing)
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.edit),
                    label: const Text("تعديل البيانات"),
                    onPressed: () {
                      setState(() => isEditing = true);
                    },
                  ),
                ),

              if (isEditing)
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton.icon(
                    icon: saving
                        ? const CircularProgressIndicator()
                        : const Icon(Icons.save),
                    label: const Text("حفظ التعديل"),
                    onPressed: saving ? null : updateProfile,
                  ),
                ),

              const Divider(height: 40),

              const Text("تغيير كلمة المرور",
                  style: TextStyle(fontSize: 18)),

              const SizedBox(height: 12),

              TextField(
                controller: oldPassCtrl,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: "كلمة المرور الحالية",
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 12),

              TextField(
                controller: newPassCtrl,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: "كلمة المرور الجديدة",
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 12),

              TextField(
                controller: confirmPassCtrl,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: "تأكيد كلمة المرور",
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.lock_reset),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                  ),
                  label: const Text("تغيير كلمة المرور"),
                  onPressed: saving ? null : changePassword,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
